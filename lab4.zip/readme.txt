Physics Questions:

1. What is Newton’s second law of motion?
Newton's second law of motion is that the acceleration of an object is directly related to the net force upon it.
(Force = mass * acceleration)

2. What is momentum? Impulse?
Momentum is a measure of an object's motion, mass * velocity. Impulse is the change in momentum.

3. What is a perfectly elastic collision?
A perfect elastic collision means no energy was lost to heat or otherwise in the collision, so the kinetic energy and
momentum before and after the collision are the same.

4. Give a real-life example of a (nearly) perfectly elastic collision.
A Newton's cradle desk toy is a good example of something nearly perfectly elastic. Some energy is lost to sound, but
the collisions continue for very long, thus showing that nearly all the energy is not lost to the environment
during the collision.

5. What is a perfectly inelastic collision?
A perfectly inelastic collision losses the maximum possible energy to the environment, so kinetic energy decreases, but
momentum remains the same.

6. Give a real-life example of a (nearly) perfectly inelastic collision.
A car crash where the cars have similar mass and velocity and do not recoil much upon collision is an example of an
inelastic collision, where all the kinetic energy is lost due to sound and heat.

7. What is the coefficient of restitution?
The measure of elasticity of a collision, measured by the ratio of the relative velocity before and after collision,
where 1 is perfectly elastic and 0 is perfectly inelastic.

8. What range of values can it take?
0 to 1, (perfectly inelastic to perfectly elastic).

9. What is angular velocity? Angular acceleration?
Angular velocity is the change of an angle over time. Angular acceleration is the rate of change of an angle over time.

10. What is the moment of inertia? Angular momentum?
The moment of inertia is the ratio of torque applied to the resulting angular acceleration of an object. Angular
momentum is the amount of rotation an object has, or the moment of inertia * angular acceleration.

11. What is torque?
Torque is rotational force that is applied to an object.

12. What is the relationship between torque, moment of inertia, and angular acceleration?
Torque is equal to the moment of inertia * angular acceleration. (T = I*alpha)

Box2d Questions:

1. In box2d, what is the difference between a Shape and a Body?
A Body represents the actual object (has physical properties like position, damping), and a Shape is the
geometric form used for collisions.

2. Between a Shape and a Body, which do you go to to change a physical property?
A Shape for physical properties such as friction and density. The Body can hold things such as position,
velocity, angular velocity, and mass.

3. To apply a force?
You can apply a force on a Body.

4. When would you want a Body to contain multiple Shapes?
If a singular Body has a shape that would require multiple basic shapes (like a circle and a rectangle).

5. In box2d, what is a World? What are some of its important properties?
The container for the physics simulator, and holds things such as gravity and all the Body's in the simulation.

6. What is the advantage of sleeping an object with a Body?
It benefits performance, as the body is inactive and not simulated.

7. When would you want to do this?
When an object has stopped moving, off-screen, or inactive.

8. In box2d, what is the difference between a static body and a dynamic body?
Static bodies do not move, whereas dynamic bodies can. Static bodies are not effected by forces, whereas dynamic bodies
are.

9. How do you specify which type a body is?
The b2BodyType can be set at creation time to make the body dynamic. Bodies are default static upon creation.

10. In box2d, what is a Bullet and when do you want an object to be one?
Bullets are fast moving objects in your World. Bullets will perform continuous collision detection with all body types
in order to prevent tunneling.

11. In LibGDX, what can you do with a ContactListener inside of a World?
A ContactListener determines when a collision stops and ends.

12. How does this help with sensors?
ContactListeners can help detect triggers such as checkpoints or win conditions.

13. In LibGDX, what are the steps that you must take to add a Shape to a Body?
You must create a dynamic body, then create a shapeDef, and then create a shape that is initialized to the body.

Ragdoll WheelObstacle:
The joint is necessary as without it, the wheel just falls due to gravity and remains out of frame. The pin won't move,
but because it is not attached to the wheel, the wheel can still just fall out of frame as it is a dynamic body.
